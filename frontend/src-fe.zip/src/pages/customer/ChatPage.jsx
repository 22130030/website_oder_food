import React, { useState, useEffect, useRef } from 'react';
import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';
import Navbar from '../../components/common/Navbar';
import Footer from '../../components/common/Footer';
import { useAuth } from '../../context/AuthContext';
import { chatAPI } from '../../services/api';
import './ChatPage.css';

const ChatPage = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const stompClientRef = useRef(null);
  const messagesEndRef = useRef(null);

  const customerId = user?.userId || user?.id;

  const formatTime = (time) => {
  if (!time) return '';

  return new Date(time).toLocaleTimeString('vi-VN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
};

  useEffect(() => {
    if (!customerId) {
      console.log('❌ Không có customerId:', user);
      return;
    }

    chatAPI.getMessagesByCustomer(customerId)
  .then(res => {
    const sortedMessages = [...res.data].sort(
      (a, b) => new Date(a.sentAt) - new Date(b.sentAt)
    );
    setMessages(sortedMessages);

    return chatAPI.markCustomerChatRead(customerId);
  })
  .then(() => {
    window.dispatchEvent(new Event('customer-chat-read'));
  })
  .catch(err => console.error('Lỗi load/mark read chat:', err));

    const client = new Client({
      webSocketFactory: () => new SockJS('http://localhost:8080/ws-chat'),
      reconnectDelay: 5000,

      onConnect: () => {
        console.log('✅ USER connected WebSocket');

        client.subscribe(`/topic/chat/${customerId}`, (message) => {
  console.log('📩 USER received:', message.body);
  const newMessage = JSON.parse(message.body);

  setMessages(prev => {
    const updatedMessages = [...prev, newMessage];
    return updatedMessages.sort(
      (a, b) => new Date(a.sentAt) - new Date(b.sentAt)
    );
  });

  if (newMessage.senderId !== customerId) {
    chatAPI.markCustomerChatRead(customerId)
      .then(() => {
        window.dispatchEvent(new Event('customer-chat-read'));
      })
      .catch(err => console.error('Lỗi mark read customer:', err));
  }
});
      },

      onStompError: (frame) => {
        console.error('❌ USER STOMP error:', frame);
      },

      onWebSocketError: (error) => {
        console.error('❌ USER WebSocket error:', error);
      },
    });

    client.activate();
    stompClientRef.current = client;

    return () => {
      client.deactivate();
    };
  }, [customerId, user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = () => {
    const senderId = user?.userId || user?.id;

    console.log('customerId:', customerId);
    console.log('senderId:', senderId);
    console.log('connected:', stompClientRef.current?.connected);

    if (!inputText.trim()) return;

    if (!customerId || !senderId) {
      alert('Không lấy được userId. Hãy đăng xuất, xóa localStorage rồi đăng nhập lại.');
      return;
    }

    if (!stompClientRef.current || !stompClientRef.current.connected) {
      alert('WebSocket chưa kết nối. Kiểm tra backend hoặc Console.');
      return;
    }

    const message = {
      customerId: customerId,
      senderId: senderId,
      content: inputText.trim(),
    };

    stompClientRef.current.publish({
      destination: '/app/chat.send',
      body: JSON.stringify(message),
    });

    setInputText('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="page-wrapper">
      <Navbar />

      <div className="chat-page">
        <div className="inner">
          <div className="chat-container card">

            <div className="chat-header">
              <div className="chat-avatar">🍔</div>
              <div className="chat-info">
                <h3>NLU-FoodStack Hỗ trợ</h3>
                <div className="online-status">
                  <span className="online-dot">●</span> Đang hoạt động
                </div>
              </div>
            </div>

            <div className="chat-messages">
              {messages.map(msg => {
                const myId = user?.userId || user?.id;
                const isMine = msg.senderId === myId;

                return (
                  <div key={msg.id} className={`msg-wrap ${isMine ? 'sent' : 'received'}`}>
                    {!isMine && <div className="msg-avatar">🤵</div>}

                    <div className="msg-bubble">
                      <p>{msg.content}</p>
                      <span className="msg-time">
                        {formatTime(msg.sentAt)}
                      </span>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <div className="chat-input-area">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Nhập tin nhắn... Enter để gửi"
                rows={1}
              />
              <button
                className="send-btn"
                onClick={sendMessage}
                disabled={!inputText.trim()}
              >
                ➤
              </button>
            </div>

          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default ChatPage;