import React, { useState, useRef, useEffect } from 'react';
import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';
import AdminLayout from '../../components/admin/AdminLayout';
import { useAuth } from '../../context/AuthContext';
import { chatAPI } from '../../services/api';
import './AdminChatManagement.css';

const AdminChatManagement = () => {
  const { user } = useAuth();

  const [conversations, setConversations] = useState([]);
  const [activeConv, setActiveConv] = useState(null);
  const [messages, setMessages] = useState([]);
  const [replyText, setReplyText] = useState('');

  // Lưu những hội thoại admin đã bấm xem trong phiên hiện tại
  const [readCustomerIds, setReadCustomerIds] = useState(new Set());

  const stompClientRef = useRef(null);
  const messagesEndRef = useRef(null);

  const formatTime = (time) => {
    if (!time) return '';

    return new Date(time).toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  };

  const sortMessagesByTimeAsc = (list) => {
    return [...list].sort((a, b) => new Date(a.sentAt) - new Date(b.sentAt));
  };

  const loadConversations = async (readCustomerId = null) => {
    try {
      const res = await chatAPI.getConversations();

      let data = res.data || [];

      // Nếu hội thoại nào đã đọc trong phiên này thì ép unreadCount = 0
      data = data.map(item => {
        if (readCustomerIds.has(item.customerId)) {
          return { ...item, unreadCount: 0 };
        }

        if (readCustomerId && item.customerId === readCustomerId) {
          return { ...item, unreadCount: 0 };
        }

        return item;
      });

      setConversations(data);
    } catch (err) {
      console.error('Lỗi load conversations:', err);
    }
  };

  useEffect(() => {
    loadConversations();

    const client = new Client({
      webSocketFactory: () => new SockJS('http://localhost:8080/ws-chat'),
      reconnectDelay: 5000,

      onConnect: () => {
        console.log('✅ ADMIN CHAT connected WebSocket');

        client.subscribe('/topic/admin/conversations', () => {
          loadConversations();
        });
      },

      onStompError: (frame) => {
        console.error('❌ ADMIN CHAT STOMP error:', frame);
      },

      onWebSocketError: (error) => {
        console.error('❌ ADMIN CHAT WebSocket error:', error);
      },
    });

    client.activate();
    stompClientRef.current = client;

    return () => {
      client.deactivate();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!activeConv) return;

    const client = stompClientRef.current;
    if (!client || !client.connected) return;

    const subscription = client.subscribe(`/topic/chat/${activeConv.customerId}`, (message) => {
      const newMessage = JSON.parse(message.body);

      setMessages(prev => sortMessagesByTimeAsc([...prev, newMessage]));

      loadConversations(activeConv.customerId);
    });

    return () => {
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeConv]);

  useEffect(() => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({
        behavior: 'smooth',
        block: 'end',
      });
    }, 100);
  }, [messages]);

  const selectConversation = async (conv) => {
    setActiveConv({ ...conv, unreadCount: 0 });
    setReplyText('');
    setMessages([]);

    // Ghi nhớ hội thoại này đã đọc để khi chuyển qua user khác không hiện lại badge
    setReadCustomerIds(prev => {
      const next = new Set(prev);
      next.add(conv.customerId);
      return next;
    });

    // Load tin nhắn trước để không bị trống màn hình
    try {
      const messagesRes = await chatAPI.getMessagesByCustomer(conv.customerId);

      console.log('Messages of customer', conv.customerId, messagesRes.data);

      const sortedMessages = sortMessagesByTimeAsc(messagesRes.data || []);
      setMessages(sortedMessages);
    } catch (err) {
      console.error('Lỗi load messages:', err);
    }

    // Sau đó mark read
    try {
      await chatAPI.markAdminConversationRead(conv.customerId);

      setConversations(prev =>
        prev.map(item =>
          item.customerId === conv.customerId
            ? { ...item, unreadCount: 0 }
            : item
        )
      );

      await loadConversations(conv.customerId);

      window.dispatchEvent(new Event('admin-chat-read'));
    } catch (err) {
      console.error('Lỗi mark read admin:', err);
    }
  };

  const sendReply = () => {
    const adminId = user?.userId || user?.id;

    if (!replyText.trim() || !activeConv || !stompClientRef.current) return;

    if (!adminId) {
      alert('Không lấy được adminId. Hãy đăng xuất rồi đăng nhập lại.');
      return;
    }

    if (!stompClientRef.current.connected) {
      alert('WebSocket chưa kết nối. Kiểm tra backend hoặc Console.');
      return;
    }

    const message = {
      customerId: activeConv.customerId,
      senderId: adminId,
      content: replyText.trim(),
    };

    stompClientRef.current.publish({
      destination: '/app/chat.send',
      body: JSON.stringify(message),
    });

    setReplyText('');
  };

  const getTotalUnread = () => {
    return conversations.reduce((sum, conv) => {
      if (readCustomerIds.has(conv.customerId)) return sum;
      return sum + Number(conv.unreadCount || 0);
    }, 0);
  };

  return (
    <AdminLayout title="💬 Quản lý Chat">
      <div className="admin-chat-layout card">

        <div className="conv-list">
          <div className="conv-list-header">
            <h3>Hội thoại</h3>
            <span className="badge badge-danger">
              {getTotalUnread()} mới
            </span>
          </div>

          {conversations.map(conv => {
            const isReadInCurrentSession = readCustomerIds.has(conv.customerId);
            const shouldShowUnreadBadge =
              Number(conv.unreadCount || 0) > 0 && !isReadInCurrentSession;

            return (
              <div
                key={conv.customerId}
                className={`conv-item ${activeConv?.customerId === conv.customerId ? 'active' : ''}`}
                onClick={() => selectConversation(conv)}
              >
                <div className="conv-avatar">
                  {conv.customerName?.charAt(0)}
                </div>

                <div className="conv-info">
                  <div className="conv-name-row">
                    <strong>{conv.customerName}</strong>
                    <span className="conv-time">
                      {formatTime(conv.lastSentAt)}
                    </span>
                  </div>

                  <p className="conv-last-msg">{conv.lastMessage}</p>
                </div>

                {shouldShowUnreadBadge && (
                  <span className="unread-badge">{conv.unreadCount}</span>
                )}
              </div>
            );
          })}
        </div>

        <div className="chat-window">
          {activeConv ? (
            <>
              <div className="chat-window-header">
                <div className="conv-avatar">
                  {activeConv.customerName?.charAt(0)}
                </div>

                <div>
                  <strong>{activeConv.customerName}</strong>
                  <p style={{ fontSize: 12, color: '#aaa' }}>
                    {activeConv.customerEmail}
                  </p>
                </div>
              </div>

              <div className="chat-window-messages">
                {messages.map((msg) => {
                  const adminId = user?.userId || user?.id;
                  const isAdmin = msg.senderId === adminId;

                  return (
                    <div
                      key={msg.id}
                      className={`message-wrapper ${isAdmin ? 'sent' : 'received'}`}
                    >
                      {!isAdmin && (
                        <div className="msg-avatar user-avatar">
                          {activeConv.customerName?.charAt(0)}
                        </div>
                      )}

                      <div className={`message-bubble ${isAdmin ? 'admin-bubble' : ''}`}>
                        <p>{msg.content}</p>
                        <span className="msg-time">
                          {formatTime(msg.sentAt)}
                        </span>
                      </div>
                    </div>
                  );
                })}

                <div ref={messagesEndRef} />
              </div>

              <div className="chat-window-input">
                <textarea
                  value={replyText}
                  onChange={e => setReplyText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendReply();
                    }
                  }}
                  placeholder="Nhập phản hồi... Enter để gửi"
                  rows={2}
                />

                <button
                  className="btn btn-primary send-btn"
                  onClick={sendReply}
                  disabled={!replyText.trim()}
                >
                  ➤
                </button>
              </div>
            </>
          ) : (
            <div className="chat-placeholder">
              <div style={{ fontSize: 64, marginBottom: 16 }}>💬</div>
              <h3>Chọn một hội thoại để bắt đầu</h3>
              <p>Bạn có {conversations.length} hội thoại</p>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminChatManagement;